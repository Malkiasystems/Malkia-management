-- ════════════════════════════════════════════════════════════════════════════
-- 014_feedback_windows.sql
--
-- Adds product-aware feedback request scheduling.
--
-- Model:
--   * Each product can optionally specify a feedback_window_days override.
--     When NULL, the default from crm_settings.feedback.default_window_days
--     applies (we ship a 7-day default).
--
--   * A new feedback_requests table tracks scheduled requests: one row per
--     (customer × voucher_line) where a feedback request is due. Rows are
--     created at sale time (via the RPC), so Brenda's CRM Command Center
--     can surface them when due_date <= today.
--
--   * Paused profiles never get rows inserted. Sensitive exits stay quiet.
--
-- Idempotent. Safe to re-run.
-- ════════════════════════════════════════════════════════════════════════════

-- ─── 1. Default feedback window ────────────────────────────────────────────
INSERT INTO crm_settings (category, key, value)
VALUES ('feedback', 'default_window_days', '{"days": 7}'::jsonb)
ON CONFLICT (category, key) DO NOTHING;


-- ─── 2. Per-product override column ────────────────────────────────────────
-- Joe can set this per product when the default 7 days isn't right.
-- E.g. perineal foam might be 14 days (needs use over time), pregnancy
-- pillow might be 3 days (instant feedback). Leave NULL to use the default.
ALTER TABLE products
  ADD COLUMN IF NOT EXISTS feedback_window_days INTEGER;


-- ─── 3. feedback_requests table ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback_requests (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id     UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  voucher_id      UUID NOT NULL,                          -- the cash sale
  voucher_line_id UUID,                                   -- specific line (optional)
  product_id      UUID,                                   -- which product
  product_name    TEXT,                                   -- snapshot at sale time
  due_date        DATE NOT NULL,                          -- when to ask
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','sent','answered','skipped','expired')),
  sent_at         TIMESTAMPTZ,
  answered_at     TIMESTAMPTZ,
  rating          INTEGER,                                -- 1-5 if answered
  feedback_text   TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_feedback_due
  ON feedback_requests(due_date)
  WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_feedback_customer
  ON feedback_requests(customer_id);

CREATE UNIQUE INDEX IF NOT EXISTS uq_feedback_voucher_line
  ON feedback_requests(voucher_line_id)
  WHERE voucher_line_id IS NOT NULL;

ALTER TABLE feedback_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS feedback_requests_read ON feedback_requests;
CREATE POLICY feedback_requests_read ON feedback_requests
  FOR SELECT TO authenticated USING (TRUE);

DROP POLICY IF EXISTS feedback_requests_write ON feedback_requests;
CREATE POLICY feedback_requests_write ON feedback_requests
  FOR ALL TO authenticated USING (TRUE) WITH CHECK (TRUE);


-- ─── 4. RPC: schedule feedback follow-ups for a posted sale ────────────────
-- Called from the cash sale post path (or backfilled). Idempotent: if a row
-- already exists for a voucher_line_id, it's skipped (via the unique index).
-- Paused profiles are skipped entirely.
--
-- For each line in the sale, computes the due_date = posting_date + window,
-- where window = products.feedback_window_days OR the default from settings.

CREATE OR REPLACE FUNCTION schedule_feedback_followups(p_voucher_id UUID)
RETURNS INTEGER AS $$
DECLARE
  v_default_days INTEGER;
  v_customer_id  UUID;
  v_paused       BOOLEAN;
  v_posting_date DATE;
  v_inserted     INTEGER := 0;
BEGIN
  -- Default window
  SELECT (value->>'days')::INTEGER INTO v_default_days
  FROM crm_settings
  WHERE category = 'feedback' AND key = 'default_window_days';
  IF v_default_days IS NULL THEN v_default_days := 7; END IF;

  -- Voucher → customer + date
  SELECT v.customer_id, v.posting_date
    INTO v_customer_id, v_posting_date
  FROM vouchers v
  WHERE v.id = p_voucher_id
    AND v.type = 'cash_sale'
    AND v.status = 'posted';

  IF v_customer_id IS NULL THEN
    RETURN 0;  -- voucher not eligible
  END IF;

  -- Skip paused profiles entirely
  SELECT stage_paused INTO v_paused FROM customers WHERE id = v_customer_id;
  IF COALESCE(v_paused, FALSE) THEN
    RETURN 0;
  END IF;

  -- Insert one feedback row per line. ON CONFLICT skip duplicates.
  INSERT INTO feedback_requests (
    customer_id, voucher_id, voucher_line_id,
    product_id, product_name, due_date
  )
  SELECT
    v_customer_id,
    p_voucher_id,
    vl.id,
    vl.product_id,
    COALESCE(vl.description, p.name),
    v_posting_date + (COALESCE(p.feedback_window_days, v_default_days) || ' days')::INTERVAL
  FROM voucher_lines vl
  LEFT JOIN products p ON p.id = vl.product_id
  WHERE vl.voucher_id = p_voucher_id
    AND vl.product_id IS NOT NULL
  ON CONFLICT (voucher_line_id) WHERE voucher_line_id IS NOT NULL DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION schedule_feedback_followups(UUID) TO authenticated;


-- ─── 5. RPC: bulk backfill for past sales (optional one-time) ──────────────
-- Schedules feedback for all cash sales in the last N days. Won't double-up
-- thanks to the unique index. Useful for the initial rollout.

CREATE OR REPLACE FUNCTION backfill_feedback_followups(p_days_back INTEGER DEFAULT 30)
RETURNS INTEGER AS $$
DECLARE
  rec       RECORD;
  v_total   INTEGER := 0;
  v_count   INTEGER;
BEGIN
  FOR rec IN
    SELECT id
    FROM vouchers
    WHERE type = 'cash_sale'
      AND status = 'posted'
      AND posting_date >= CURRENT_DATE - (p_days_back || ' days')::INTERVAL
      AND customer_id IS NOT NULL
  LOOP
    v_count := schedule_feedback_followups(rec.id);
    v_total := v_total + v_count;
  END LOOP;
  RETURN v_total;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION backfill_feedback_followups(INTEGER) TO authenticated;


-- ─── 6. View: due feedback requests (for the CRM Command Center later) ─────
CREATE OR REPLACE VIEW feedback_due_today AS
SELECT
  fr.id AS feedback_id,
  fr.customer_id,
  c.name AS customer_name,
  c.whatsapp,
  fr.voucher_id,
  fr.product_name,
  fr.due_date,
  (CURRENT_DATE - fr.due_date) AS days_overdue,
  fr.status,
  c.stage_paused
FROM feedback_requests fr
JOIN customers c ON c.id = fr.customer_id
WHERE fr.status = 'pending'
  AND fr.due_date <= CURRENT_DATE
  AND c.is_active = TRUE
  AND c.stage_paused = FALSE        -- paused profiles excluded
ORDER BY fr.due_date ASC;

GRANT SELECT ON feedback_due_today TO authenticated;

-- ════════════════════════════════════════════════════════════════════════════
-- END 014_feedback_windows.sql
-- ════════════════════════════════════════════════════════════════════════════
